function res = getEigenVecs(a)
res = a.eigenVecs;
