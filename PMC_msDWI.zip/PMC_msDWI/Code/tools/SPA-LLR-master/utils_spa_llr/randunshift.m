function out = randunshift(in,r)
% Unshifts

out = circshift(in,-r);